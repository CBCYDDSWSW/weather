Page({
    data:{
        region:['山东省','青岛市','崂山区'],
        regionId:101010100, 
        now:{
            tmp:0,
            cond_txt:'未知',
            cond_code:'999',
            hum:0,
            pres:0,
            vis:0,
            wind_dir:0,
            wind_spd:0,
            wind_sc:0
        }   
    },
    regionChange:function(e){
        this.setData({region:e.detail.value});
        this.getWeather();
    },
    getWeather:function(){
        var that = this;

        wx.request({
          url: 'https://geoapi.qweather.com/v2/city/lookup',
          data:{
              location:that.data.regionId[1],
              key:'b3dbe99359b04a75a87ccead63443aab'
          },
          success:function(res){
            that.setData({regionId:res.data.location[0].id});
        
            console.log(that.data.regionId);
          }
        })

        wx.request({
            url: 'https://devapi.qweather.com/v7/weather/now',
            data:{
                location:that.data.regionId,
                key:'b3dbe99359b04a75a87ccead63443aab'
            },
            success:function(res){
                that.setData({now:res.data.now});
                console.log(66);
            }
          })
    },

    onLoad(options){
        this.getWeather();
    }
})